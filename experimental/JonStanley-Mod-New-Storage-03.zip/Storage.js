// Tek 4051 Emulator Storage Script
// 31-12-2022


function Storage() {
    fileIndex = [];
    let storage;
    let content = new ArrayBuffer();
    let binData = [];
    let binDataPtr = 0;
    let currentFile = "";

    const copylen = 256;
    const copyterm = 0x80;
    let copycnt = 0;
    let dirLength = 0;
    let dirFidx = 0;
    let dirFname = "";
    let dirFnamePtr = 0;
    const fileLength = 46;    // Including CR and NULL
    const filesPerDirectory = 254;
    let directoryName = "/root/";
    let padcnt = 0;
    
    const fileTypes = [
        {idx:'A',type:'ASCII'},
        {idx:'B',type:'BINARY'},
        {idx:'N',type:'NEW'},
        {idx:'L',type:'LAST'}
    ]; 

    const fileUsages = [
        {idx:'P',usage:'PROG'},
        {idx:'D',usage:'DATA'},
        {idx:'L',usage:'LOG'},
        {idx:'T',usage:'TEXT'}
    ]; 

    // Initialise the file index and and list
//    loadfileIndex();
/*
    Option to load "virtual disk" from file ?
*/
    updateFileList();


    // Initialise
    this.init = function(object){
        storage = object;
    }


    // Save a file to web storage
    this.saveFile = function(){

        let filelistobj = document.getElementById('fileList');
        let fileNumObj = document.getElementById('fileNum');

        // Get the value of the file number field
        let filenum = parseInt(fileNumObj.value);
        // If the value is not defined or out of rasnge then make it zero
        if (!filenum) filenum = 0;
        if (filenum>filesPerDirectory) filenum = 0;

        // If value is zero (no file number set) then prompt for one
        while (filenum == 0) {
            let nextfnum = getNextAvailableFnum();
            if (nextfnum) {
                filenum = prompt("Please provide a file number (max. " + filesPerDirectory + "):", nextfnum);
                // Cancelled to exit function
                if (!filenum) return;
                // File number out of range, try again
                if (filenum>filesPerDirectory) filenum = 0;
            }else{
                // No available next file number found
                alert("Unable to save. No free file numbers available!");
                return;
            }
        }

        // If we have a file number then Save the file
        if (filenum) {
console.log("76-Content: ", content);
            // Get the file index
            let idx = findFileRecord(filenum.toString());
            // If file exists in storage then prompt to overwrite else push new entry to file list
            if (idx>-1) {
                if (confirm("Overwrite existing file?")) {
                    fileIndex[idx][5] = content;
                }else{
                    return;
                }
            }else{
                // Add new record to array and get its index
                idx = fileIndex.push([filenum, "", "", "", "", content]) - 1;
            }
            // Save file settings to index
            updateRecordFromControls(idx);
            // Clear and re-build the file list
            clearFileList();
            updateFileList();
            // Set currently selected item in Select dropdown
            selectCurrentFile(filenum.toString());
        }
    }


    // Retrieve a file from web storage
    this.loadFile = function(){
        // Get the selected file number
        let fileListObj = document.getElementById('fileList');
        if (fileListObj.selectedIndex>-1) {
            currentFile = fileListObj.options[fileListObj.selectedIndex].text;
            // Update the file number field
            let filenumobj = document.getElementById('fileNum');
            filenumobj.value = currentFile;
            // Load the file
            if (currentFile != "") {
                selectCurrentFile(currentFile);
            }else{
                alert("File number required!");
            }
        }
    }


    // Remove file from web storage
    this.deleteFile = function(){
        let fileListObj = document.getElementById('fileList');
        let fileNumObj = document.getElementById('fileNum');
        let fnumstr;
        if (fileListObj.selectedIndex>-1){
            fnumstr = fileListObj.options[fileListObj.selectedIndex].text;
        }else{
            fnumstr = fileNumObj.value;
        }
        if (fnumstr != '') {
            let idx = findFileRecord(fnumstr);
            if (idx>-1) {
                if (confirm("Delete existing file?")){
                    // Delete file
                    clearFileList();
                    content = new ArrayBuffer();

                    fileIndex.splice(idx, 1);

                    updateFileList();
                    clearIndexEntry(fnumstr);
                    this.clearView();
                }
            }else{
                alert("Nothing to delete!");
            }
        }else{
            alert("Select a file number to delete!");
        }
    }


    // Select file for upload to Tek when 'Select' button clicked
    // OLD@1: called from the emulator then loads the file into the emulator
    this.selectTekFile = function(){
        // Get the currently selected file number
        let fnumstr = document.getElementById('fileNum').value;
        // If itd not null...    
        if (fnumstr != "") {
            // Find the file index
            let idx = findFileRecord(fnumstr);
            if (idx>-1) {
                // Get program data for file
                upload_to_tek(fileIndex[idx][5]);
                // Close the storage window
                this.closeStorageWindow();
            }

        }
    }


    // Clear index entries
    function clearIndexEntry(fnumstr){
        if (fileIndex && fileIndex.length > 0){
            let i = 0;
            while (i < fileIndex.length) {
                if (fileIndex[i][0] == fnumstr) {
                    fileIndex.splice(i,1);
                }else{
                    i++;
                }
            }
        }
    }


    // Clear file from viewer
    this.clearView = function(){
        content = new Uint8Array();
        document.getElementById('fileList').value = "";
        document.getElementById('fileViewer').value = "";
        document.getElementById('fileType').value = "";
        document.getElementById('fileUsage').value = "";
        document.getElementById('fileDesc').value = "";
        document.getElementById('fname').innerHTML = "Drop a file to this window";
        document.getElementById('fileNum').value = "";
        document.getElementById('fileSize').value = "";
    }


    // Delete everything in web storage
    this.deleteAll = function(){
        if (confirm("WARNING: this will clear ALL storage and cannot be undone!\nDo you still wish to continue?")){
            // Clear viewer
            this.clearView();
            content = new ArrayBuffer();
            // Clear file select control (file list)
            clearFileList();
            // Clear file index
            fileIndex = [];
        }
    }


    // Hide the storage window
    this.closeStorageWindow = function(){
        let storageobj = document.getElementById('storage');
        storageobj.style.display="none";
    }


    // Read a file from disk into web storage
    function readFile(file, storageobj){
        if (file) {
            let filename = file.name;
            let filenamefield = document.getElementById('fname');
            let freader = new FileReader();
            filenamefield.innerHTML = filename;

            // Set up freader
            freader.onload = function(ev) {

                // Copy read file data to buffer 
                content = ev.target.result;

                // Get page object references
                let fsize = document.getElementById('fileSize');
                let fnumobj = document.getElementById('fileNum');
                let tekUploadFlg = document.getElementById('tekUploadFlg');

                if (tekUploadFlg.value == "1") {  // Uploading from file directly to Tek?
                    // Upload file directly to the emulator
                    upload_to_tek(ev.target.result);
                    // Signal Tek that  program has loaded
                    tek.programLoaded();
                    // Reset direct to Tek upload flag
                    tekUploadFlg.value = 0; 
                }else{  // Load into content buffer and storage
                    // Sanity check: is it a 405x Flash Drive file?
                    let flashFileInfo = isFlashFile(filename);
                    if (flashFileInfo) {
                        fnumobj.value = flashFileInfo[0];
                        // Does a record for the file already exist?
                        let idx = findFileRecord(flashFileInfo[0]);
                        // If file exists...
                        if (idx>-1) {
                            // Confirm the overwrite
                            if (confirm("Overwrite existing file?")) {
                                fileIndex[idx][5] = content;
                            }else{
                                return;
                            }
                        }else{
                            // Update/create new file record from file info
                            updateFileRecord(flashFileInfo);
                            // Save the new file content
                            idx = findFileRecord(flashFileInfo[0]);
                            fileIndex[idx][5] = content;
                        }

                        // Update viewer controls
                        updateCtrlsFromRecord(fnumobj.value);
                        updateFileList();
/*
                    }else{
                        content = ev.target.result;
*/
                    }
                    displayInViewer(ev.target.result);
                }
            }

            // Call freader
            freader.readAsArrayBuffer(file);    

        }
    }


    // Update the viewer window
    function displayInViewer(filecontent){

        let viewerobj = document.getElementById('fileViewer');

        // Clear current content
        viewerobj.value = "";

        // Upload new content
        if ( (typeof filecontent != 'undefined') && (filecontent.byteLength > 0) ) {
            let enc = new TextDecoder
            viewerobj.value = enc.decode(filecontent);
        }
    }


    // Handler to import files in 405x Flash Drive format
    function importFlashDir(storageObj){
        let fileobj = document.getElementById('importObj');
        let filelistobj = document.getElementById('fileList');
        let fnumobj = document.getElementById('fileNum');
        let numfiles = fileobj.files.length;
        let freader = new FileReader();

        // Clear the storage viewer
        storageObj.clearView();

//        alert("Importing files....\nIf many files have been selected this may take some time.\nPress OK to start.");
        showStorageMsg("Importing Flash Drive files ...",'',0);


        function readNextFile(fidx) {
            if (fidx >= numfiles) return;
            let file = fileobj.files[fidx];
            // Get the next file name
            let filename = file.name;

            // File read handler
            freader.onload = function(ev) {
                
                let flashFileInfo = isFlashFile(filename);  // Sanity check - valid Flash Drive file?
                if (flashFileInfo){
                    // Get the file number and set the F# field
                    fnumobj.value = flashFileInfo[0];
                    // Update or create file record
                    updateFileRecord(flashFileInfo);
                    // Save file content
                    let lidx = findFileRecord(flashFileInfo[0]);
                    fileIndex[lidx][5] = ev.target.result;
                    // Update viewer controls
                    updateCtrlsFromInfo(flashFileInfo);
                    updateFileList();
                }

                if ( fidx == (numfiles-1) )  {  // Reached the last file
                    // Select the first file
                    filelistobj.selectedIndex = 0;
                    // Trigger the 'change' event to display the file in viewer
                    filelistobj.dispatchEvent(new Event('change'));
                    // Signal that import has completed
                    clearStorageMsg();
                    showStorageMsg("Done.",'',1);

//                    alert("Import completed.");
                    numfiles = 0;
                }else{
                    readNextFile(fidx+1);
                }
            }
            freader.readAsArrayBuffer(file);
        }
        readNextFile(0);

        // Finished with importing multiple files
        fileobj.removeAttribute('multiple','');
    }


    // Import the storage archive
    function importStorageArchive(storageObj){

        let loadfile = document.getElementById('importObj').files[0];
        let freader = new FileReader();

        // Clear the storage viewer and storage data
        storageObj.clearView();
        storageObj.fileIndex = [];

//        alert("Importing files....\nThis may take some time.\nPress OK to start.");
        showStorageMsg("Importing storage archive ...",'',0);
                    
        // File read handler
        freader.onload = function(ev) {

            JSZip.loadAsync(ev.target.result).then(function(zipcontainer) {
                getArchiveContent(zipcontainer);
                clearStorageMsg();
                showStorageMsg("Done.",'',1);
                
            }).catch(function(err) {
                alert("Failed to open file: ", loadfile.name);
            })
            
        }
        freader.readAsArrayBuffer(loadfile);

    }


    // Helper for storage archive importer
    async function getArchiveContent(zipContainer){

        let fileListObj = document.getElementById('fileList');
        let i = 0;
        let tflg = 0;
        let idx = 0;

        for(let [filename, fileObj] of Object.entries(zipContainer.files)) {

            if (tflg) { // File content
                const fileData = await fileObj.async("arrayBuffer");
                idx = fileIndex.length-1;
                fileIndex[idx].push(fileData);
                tflg = 0;   // Next file is header 
            }else{  // File header
                const fileData = await fileObj.async("string");
                fileIndex.push(JSON.parse(fileData));
                tflg = 1;   // Next file is content 
            }

        }    

        updateFileList();
        // Select the first file
        fileListObj.selectedIndex = 0;
        // Trigger the 'change' event to display the file in viewer
        fileListObj.dispatchEvent(new Event('change'));
        // Signal that import has completed
//        alert("Import completed.");

    }


    // Process file dropped onto viewer window
    this.dropHandler = function(ev, storageObj) {
        let file;
        // Prevent default behavior (Prevent file from being opened)
        ev.preventDefault();

        if (ev.dataTransfer.items) {
            // Use DataTransferItemList interface to access the file(s)
            // If dropped items aren't files, reject them
            if (ev.dataTransfer.items[0].kind === 'file') file = ev.dataTransfer.items[0].getAsFile();
        } else {
            // Use DataTransfer interface to access the file(s)
            file = ev.dataTransfer.files[0];
        }
        storageObj.clearView();
        readFile(file, storageObj);
    }


    // Prevent default dragover action
    this.dragOverHandler = function(event){
        event.preventDefault();
    }


    // Storage import/export options
    this.storageAdm = function(inbound){
        let idx = document.getElementById('importType').selectedIndex;

        if (idx == 0) {
            if (inbound) {
                document.getElementById('importObj').click();
            }else{
                exportFile('file.txt', 'text/plain');
            }   
        } else if (idx == 1) {
            if (inbound) {
                if (confirm("WARNING: This will overwite all current files!")) {
                    document.getElementById('importObj').click();
                }else{
                    return;
                }
            }else{
                exportStorageArchive();
            }   
        } else if (idx == 2) {
            if (inbound) {
                if (confirm("WARNING: This will overwite all existing files with the same file number!")) {
                    let multifile = document.getElementById('importObj');
                    multifile.setAttribute('multiple','true');
                    multifile.click();
                }else{
                    return;
                }
            }else{
                exportFlashFiles();
            }   
        } else {
            alert("ERROR: shouln't get here!");    
        }
    }


    // Import handler
    this.importObject = function(storageObj) {
        let idx = document.getElementById('importType').selectedIndex;

        if (idx == 0) {
            let file = document.getElementById('importObj').files[0];
            readFile(file, storageObj);
        } else if (idx == 1) {
            importStorageArchive(storageObj);
        } else if (idx == 2) {
            importFlashDir(storageObj);
        }

    }


    // File export handler
    function exportFile(filename, contentType) {
        let fnumstr = getCurrentFileNum();
        let idx = findFileRecord(fnumstr);
        if ( (idx>-1) && (fileIndex[idx][5]) ){
            // Create a file object and perform the export
            const file = new Blob([fileIndex[idx][5]], {type: contentType});
            performExport(filename, file);
        }else{
            alert("Nothing to export!");
        }
    }


    // Handler to export 405x tagged files only to Flash Drive format
    function exportStorageArchive(){
        let fnumstr = "";
        let filename;
        let zip = new JSZip();
        let idx = 1;

        if (fileIndex.length>0) {

            for(let i in fileIndex){
                let buffer;
                let filename;

                buffer = [fileIndex[i][0], fileIndex[i][1], fileIndex[i][2], fileIndex[i][3], fileIndex[i][4]];
                filename = idx.toString().padStart(4,'0');
                zip.file(filename, JSON.stringify(buffer));

                idx++;
                if (fileIndex[i][5]) buffer = fileIndex[i][5];
                filename = idx.toString().padStart(4,'0');
                zip.file(filename, buffer);
                idx++;
            }

            zip.generateAsync({type:"blob"}).then(function(zipcontent) {
                performExport("Archive.zip", zipcontent);
            });

        }
    }


    // Handler to export 405x tagged files only to Flash Drive format
    function exportFlashFiles(){
        let filelistobj = document.getElementById('fileList');
        let fnumstr = "";
        let idx = 0;
        let filename;
        let zip = new JSZip();

        if (filelistobj && filelistobj.length>0) {

            showStorageMsg("Exporting Flash Files...", '', 0);

            for(let i=0; i<filelistobj.length; i++){
                fnumstr = filelistobj[i].text;
                filename = "";
                content = new ArrayBuffer();
                idx = findFileRecord(fnumstr);
                if (idx>-1) {
                    filename = getFilename(fnumstr);
                    if (isFlashFile(filename)) {    // Export tagged flash files only
                        if (fileIndex[idx][5]) content = fileIndex[idx][5];                       
//                            if (filename === "") filename = "File-" + fnumstr + ".tek";
                        zip.file(filename, content);
                    }
                }
            }

            zip.generateAsync({type:"blob"}).then(function(zipcontent) {
                performExport("4050files.zip", zipcontent);
            });
        }
    }


    // File export handler
    async function performExport(filename, fileobj) {
        const exported = document.createElement('a');
        exported.href = URL.createObjectURL(fileobj);
        exported.download = filename;
        exported.click();
        URL.revokeObjectURL(exported.href);
        exported.remove();
        clearStorageMsg();
alert("Done!");        
    }


    // Show the storage window
    this.showStorageOptions = function(){
        let storage = document.getElementById('storage');
        let idx = "0";
        clearFileList();
        updateFileList();
        storage.style.display="block";
    }


/*
    // Convert string to uint8 array
    function str2uint8Array(str) {
        if (str) {
            let tempArray = new Uint8Array(str.length);
            for (let i=0; i<str.length; i++) {
                tempArray[i] = str.charCodeAt(i);
            }
        }
        return tempArray;
    }
*/

    // Handler to upload program to the Tek emulator
    this.readFromTape = function(fnum,type) {
        if (fnum == "0") { // Read disk file directly into tek emulator
            let progObj = document.getElementById('fileViewer');
            let tekUploadFlg = document.getElementById('tekUploadFlg');
            progObj.value = "";
            // Signal we want to upload directly into the emulator
            tekUploadFlg.value = "1";
            // Trigger the file dialog to let the user choose a file
            document.getElementById('importObj').click();
        }else{  // File index > 0 read file from storage
            // Get index of file
            let idx = findFileRecord(fnum);
            // File index exists then read file from storage
            if (idx>-1) {
                if (fileIndex[idx][5]) {
                    // Valid for tagged files but not NEW or LAST
                    if ( (type == 'A') || (type == 'B') ) upload_to_tek(fileIndex[idx][5]);
                }else{
                    // Force Tek error message
                    upload_to_tek_fail();
                }
            }
        }
    }


    // Prepare to save file to storage
    this.saveToTapeReady = function(){
        // Clear the viewer
        let fileViewerObj = document.getElementById('fileViewer');
        fileViewerObj.value = "";
        // Clear Tek data handling array
        binData = [];
        binDataPtr = 0;
    }


    // Push binary data character to data handling array
    this.saveToTapeBin = function(pchar) {
        binData.push(pchar);
    }


    // Save binary data handling array to storage
    this.saveToTapeDone = function(fnumstr,type) {
        let fnumobj = document.getElementById('fileNum');
        displayInViewer(binData);
        fnumobj.value = fnumstr;
        if (fnumstr == '0') {

            // Create a file object and perform the export
            const file = new Blob([Uint8Array.from(binData)], {type: 'text/plain'});
            performExport('file.txt', file);

        }else{

            // Create/update file record
            let idx = findFileRecord(fnumstr);
            if (idx>-1) {
                fileIndex[idx][1] = type;
                fileIndex[idx][2] = 'P';
                fileIndex[idx][5] = Uint8Array.from(binData).buffer; 
            }else{
                fileIndex.push([currentFile,type,'P','N',"",Uint8Array.from(binData).buffer]);
            } 
//            updateCtrlsFromRecord(currentFile);
        }
    }


    // PRINT to a type NEW or ASCII file. Change type NEW to ASCII.
    this.printToFile = function(byte){
        let idx = findFileRecord(currentFile);
        if (idx > -1) {
            let ftype = fileIndex[idx][1];
            // Print only to files of type NEW, ASCII or unmarked
            if ( (ftype == "") || (ftype == 'N') || (ftype == 'A') ) {
                if (binDataPtr == 0) binData = [];
                binData.push(byte);
                binDataPtr++;
                // Change type NEW to type ASCII
                if ( (ftype == "") || (ftype == 'N') ) {
                    fileIndex[idx][1] = 'A';
                    fileIndex[idx][2] = 'D';
                    updateCtrlsFromRecord(currentFile);
                }
            }
        }
    }


    // WRITE to a type NEW or BINARY file. Change type NEW to BINARY.
    this.writeToFile = function(byte){
        let idx = findFileRecord(currentFile);
        if (idx > -1) {
            let ftype = fileIndex[idx][1];
            // Write only to files of type NEW, BINARY or unmarked
            if ( (ftype == "") || (ftype == 'N') || (ftype == "B") ) {
                if (binDataPtr == 0) binData = [];
                binData.push(byte);
                binDataPtr++;
                // Change type NEW to type BINARY
                if ( (ftype == "") || (ftype == 'N') ) {
                    fileIndex[idx][1] = 'B';
                    fileIndex[idx][2] = 'D';
                    updateCtrlsFromRecord(currentFile);                
                }
            }
        }
    }



    // Terminator (CR) received or write completed. Save the file to storage.
    this.writeToFileDone = function(){
        let idx = findFileRecord(currentFile);
        content = Uint8ClampedArray.from(binData);
        if (idx>-1){
            fileIndex[idx][5] = content;
        }
    }


    // INPUT data from ASCII file
    this.inputFromFile = function(){
        let idx = findFileRecord(currentFile);
        let ftype = fileIndex[idx][1];
        // Read a byte only from files of type ASCII (ASCII data, prog, log or text)
        if (ftype == 'A') {
            if (binDataPtr < binData.length){
                let byte = binData[binDataPtr];
                binDataPtr++;
                return byte;
            }
        }
        return 0xFF;
    }


    // COPY/INPUT data from a file
    this.copyFromFile = function(){
        let idx = findFileRecord(currentFile);
        let ftype = fileIndex[idx][1];
        // Read a byte only from files of type ASCII (ASCII data, prog, log or text), or unassigned
        // This will make a NEW or unassigned file ASCII DATA
        if (ftype == 'A') {
            let byteval;
            if ( (binDataPtr < binData.length) ){
                byteval = binData[binDataPtr];
                if ( (byteval == copyterm) || (byteval == 0x0D) ) copycnt = copylen;
                if (binDataPtr == binData.length) byteval = 0x01FF;    // End of file
//console.log("Copycnt: " + copycnt);
/*
                if (copycnt == copylen-1){    // Copy length reached
                    byteval = byteval0x1;
                    binDataPtr--;
                    copycnt = 0;
                }else{
                    copycnt++;
                }
*/
                if (copycnt == copylen) {
                    byteval = 0x1FF;
                    copycnt = 0;
                }else{
                    copycnt++;
                }
                binDataPtr++;
                return byteval;
            }
        }
        return 0x1FF;
    }


    // READ from BINARY data file
    this.readFromFile = function(){
        let idx = findFileRecord(currentFile);
        let ftype = fileIndex[idx][1];
        let fusage = fileIndex[idx][2];
        // Read a byte only from files of type ASCII (ASCII data, prog, log or text), or unassigned
        // This will make a NEW or unassigned file ASCII DATA
        if ( (ftype == 'B') && (fusage == 'D') ) {
            if ( (binDataPtr < binData.length) && binData.length ){
                let byte = binData[binDataPtr];
                binDataPtr++;
                return byte;
            }
        }
        return 0x1FF;
    }


    // Read from BINARY PROG file
    this.readBinProg = function(){
        let idx = findFileRecord(currentFile);
        if (idx >= 0) {
            let ftype = fileIndex[idx][1];
            let fusage = fileIndex[idx][2];
            if (binData.length && (binData.length>0) ) {
                if (padcnt==0) padcnt = (256 - (binData.length % 256) );
                // Read only from BINARY PROGRAM file
                if ( (ftype == 'B') && (fusage == 'P') ) {
                    let dataval;
                    if (binDataPtr < binData.length) dataval = binData[binDataPtr];
//                if (binDataPtr == binData.length) dataval = 0x01FF;
//                if (binDataPtr == binData.length-1) dataval += 0x100;
                    binDataPtr++;
                    if ( (binDataPtr-1) < binData.length ) {
                        return dataval;
                    }else if ( (binDataPtr-1) == binData.length ){
//                        padcnt--;
                        return 0xFF;
                    }else{
//console.log("Padding required: " + padcnt);
//                        padcnt--;
//                        if (padcnt>0) {
//console.log("Storage sent 0x20.");
                            return 0x20;
//                        }else if (padcnt==0) {
//console.log("Storage sent 0x20 with EOI!");
//                            return 0x120;
//                        }else{
//                            return 0x1FF;
//                        }
                    }
                }
            }
        }
        return 0x01FF;  // Null response with EOI
    }


    // FIND command - select the requested file
    this.findFile = function(fnumstr){
        if (parseInt(fnumstr) > 0 && parseInt(fnumstr) < 255) {
            currentFile = fnumstr;
            binDataPtr = 0;
            copycnt = 0;

            // Make the requested file the current file
            selectCurrentFile(fnumstr);
            // Get its file type
//            let ftype = document.getElementById('fileType').value;
            // Get it index
            let idx = findFileRecord(fnumstr);
            if (idx>-1) {
                // If file has content ...       
//                if (fileIndex[idx] && fileIndex[idx][5]) {
                if ( (typeof fileIndex[idx][5] != 'undefined') && (fileIndex[idx][5].byteLength>0) ) {
                        // File type is ASCII or BINARY program or data (NOT NEW, LAST or unmarked)
//                      if ( (ftype == 'A') || (ftype == 'B') ) {
                            let tmpBuf = new Uint8ClampedArray(fileIndex[idx][5]);
                            binData = Array.from(tmpBuf);
//                      }else{
//                          binData = [];
//                      }
                }else{
                    // Create an empty array
                    binData = [];
                }

            }else{

                // Create a new record
                fileIndex.push([parseInt(fnumstr), "", "", "", ""]);

            }

        }
    }


    // CLOSE command - close the requested file
    this.closeFile = function(){
        let filelistobj = document.getElementById('fileList');
        content = new ArrayBuffer();
        binData = [];
        binDataPtr = 0;
        currentFile = "";
        copycnt = 0;
        this.clearView();
        filelistobj.value = "";
    }


    // Return the current directory
    this.getDirectory = function() {
        if (dirFnamePtr == directoryName.length) {
            // Reset pointer to beggining of string, send CR
            dirFnamePtr = 0;
            dirFname = "";
            return 0x0D;
        }else{
            // Send byte
            dirFnamePtr++;
            return directoryName.charCodeAt(dirFnamePtr-1);
        }
    }


    // Get the name of the current file and send it to the 4051
    this.getDirEntry = function(){
        let filelistobj = document.getElementById('fileList');
        if (dirFnamePtr == 0) {
            let idx = findFileRecord(currentFile);
            let filename = "";
            let stat = 0;
            // File exists in index
            if (idx > -1) {
                stat++;
                // File is marked
                if ( (fileIndex[idx][1] == "A") || (fileIndex[idx][1] == "B") ) {
                  if (fileIndex[idx][2] != "") stat++;
                }
                if ( (fileIndex[idx][1] == "N") || (fileIndex[idx][1] == "L") ) {
                  stat++;
                }
                // Filename is not blank
                filename = getFilename(currentFile);
                if (filename != "") stat++;
            }
            if (stat == 3) {
                // Valid filename
                dirFname = filename;
                dirFnamePtr++;
                return dirFname.charCodeAt(0);
            }else{
                // No filename - null return
                dirFnamePtr = 0;
                return 0xFF;            
            }
        }else{
            if (dirFnamePtr == dirFname.length) {
                // Reset pointer to beggining of string, send CR
                dirFnamePtr = 0;
                dirFname = "";
                return 0x0D;
            }else{
                // Send byte
                dirFnamePtr++;
                return dirFname.charCodeAt(dirFnamePtr-1);
            }
        }
    }


    this.setDirEntry = function(rbyte){
//        console.log(String.fromCharCode(rbyte));
        if (rbyte == 0x0D) {
//            console.log("Filename: " + dirFname);

            // Valid format for marked file
            if ( fileInfo = isFlashFile(dirFname)) {
                updateFileRecord(fileInfo);
                updateCtrlsFromInfo(fileInfo);
//                savefileIndex();
            }

            // Some process here
            dirFname = "";
            dirFnamePtr = 0;
        }else{
            dirFname += String.fromCharCode(rbyte);
        }
    }


/*
    function fileIndexCount() {
        let i = 0;
        for (i in fileIndex) {
        }
        return i;
    }
*/

    // Select the current file - load file and update controls and index
    function selectCurrentFile(fnumstr){
        if (fnumstr) {
            // Set global current file indicator
            currentFile = fnumstr;  

            // Get references to page file description objects
            let filelistobj = document.getElementById('fileList');
            let fnameobj = document.getElementById('fname');
            let fdescobj = document.getElementById('fileDesc');

            // Clear the viewer
            displayInViewer("");

            // Show the current file number
            filelistobj.value = fnumstr;

            // Get the current file record index
            let idx = findFileRecord(fnumstr);

            // Display file description if available           
            if (idx>-1) {
                let fileinfo = fileIndex[idx];
                updateCtrlsFromRecord(fnumstr);
                if (fileinfo[3] == "") {
                    fnameobj.innerHTML = "No description";
                    fdescobj.value = "";
                }else if ( (fileinfo[3]=='N') || (fileinfo[3]=='S') ) {   // Temp to deal with Secret
                    if (fileinfo[4] == "") {
                        fnameobj.innerHTML = "No description";
                        fdescobj.value = "";
                    }else{
//console.log("Fname present");
                        fnameobj.innerHTML = getFilename(fileinfo[0]);
                        fdescobj.value = getFileDescription(fileinfo[4]);
                    }
                }else if ( (fileinfo[1]=='') || (fileinfo[2]=='') ){
                    if ( (fileinfo[1]=='N') || (fileinfo[1]=='L') ) {
                        if (fileinfo[1]=='N') fnameobj.innerHTML = "NEW";
                        if (fileinfo[1]=='L') fnameobj.innerHTML = "LAST";
                        fdescobj.value = "";
                    }else{
//console.log("Not marked");
                        fnameobj.innerHTML = "File not marked!";
                        fdescobj.value = fileinfo[3];
                    }
                }else{
//console.log("Other");
                    fnameobj.innerHTML = getFilename(fileinfo[0]);
                    fdescobj.value = fileinfo[3];
                }
                // If we have a code object, display it in viewer
//                if ( (typeof fileIndex[idx][5] != 'undefined') && (fileIndex[idx][5].byteLength > 0) ) {
                if (typeof fileIndex[idx][5] != 'undefined') {
                    displayInViewer(fileIndex[idx][5]);
                }
            }else{  // No record available
                fnameobj.innerHTML = "No description";
                fdescobj.value = "";
            }
        }
    }


    // Clear the file select control
    function clearFileList() {
        let fileListObj = document.getElementById('fileList');
        if (fileListObj) {
            let listlen = fileListObj.length;
            while(listlen--){
                fileListObj.remove(listlen);
            }
        }
    }



    // Update the file select control
    function updateFileList() {
        let fileList = new Array();
        let fileListObj;

        // Create an index of file numbers
        if (fileIndex) {
            for (let i=0; i<fileIndex.length; i++) {
                fileList.push(fileIndex[i][0]);
            }
            if (fileList) fileList.sort(function(a,b){return a - b});
        }

        // If we have a populated list then update the file select control
        if (fileList) {
            clearFileList();
            fileListObj = document.getElementById('fileList');
            // Create file select list
            for (let i=0; i<fileList.length; i++) {
                let fnumstr = fileList[i].toString();  // Control values are text
                if (fnumstr != "999") {
                    let opt = document.createElement('option');
                    opt.textContent = fnumstr;
                    opt.value = fnumstr;
                    fileListObj.appendChild(opt);
                }
            }
            // Delselect any selected option
            fileListObj.selectedIndex = -1;
        }
    }



    this.changeType = function(){
        let filenumstr = getCurrentFileNum();
        if (filenumstr) {
            // Get the type setting
            let typeobj = document.getElementById('fileType');
            let type = typeobj.options[typeobj.selectedIndex].value;
            // Attempt to find the relevant record
            let idx = findFileRecord(filenumstr);
            // If no record then create one otherwise update
            if (idx<0) {
                fileIndex.push([filenumstr,type,'N',"",""]);
            }else{
                fileIndex[idx][1] = type;
            }
        }
    }


    this.changeUsage = function(){
        let filenumstr = getCurrentFileNum();
        if (filenumstr) {
            // Attempt to find the relevant record
            let idx = findFileRecord(filenumstr);
            // Get the type setting
            let usageobj = document.getElementById('fileUsage');
            let usage = usageobj.options[usageobj.selectedIndex].value;
            // If no record then create one otherwise update
            if (idx<0) {
                fileIndex.push([filenumstr,'N',usage,"",""]);
            }else{
                fileIndex[idx][2] = usage;
            }
        }
    }


    // Returns the file number currently selected in the Select drop down
    function getCurrentFileNum(){
        let listobj = document.getElementById('fileList');
        if (listobj.selectedIndex>-1) {
            let filenum = listobj.options[listobj.selectedIndex].text;
            return filenum;
        }
        return "";
    }


    // Finds the index of the file record given a file number
    // Not found returns -1
    function findFileRecord(fnumstr){
        let idx = -1;
        let fnumval = parseInt(fnumstr);
        if (fileIndex) {
            for (let i=0; i<fileIndex.length; i++) {
                if (fileIndex[i][0]==fnumval){
                    idx = i;
                    break;
                }
            }
        }
        return idx;
    }


    // Save file index to storage
/*
    function savefileIndex() {
        let stringified = "";
        let cnt;
        if (fileIndex) {
            fileIndex.forEach((record, i, array) => {
                stringified += record;
                if (i < (array.length-1)) stringified += ':';
            });
        }
        localStorage.setItem("999", stringified);
    }
*/

    // Retrieve file index from storage
/*
    function loadfileIndex() {
        let record = [];
        let index = [];
        let raw = [];
        stringified = localStorage.getItem("999");
        if (stringified) {
            raw = stringified.split(':');
            raw.forEach(item => { record = item.split(','); index.push(record)});
            fileIndex = index;
        }
    }
*/

    // Update file info controls from index
    function updateCtrlsFromInfo(fileinfo) {
        let ftype = document.getElementById('fileType');
        let fusage = document.getElementById('fileUsage');
        let fdesc = document.getElementById('fileDesc');
        let fsize = document.getElementById('fileSize');
        let idx = findFileRecord(fileinfo[0]);

        ftype.value = fileinfo[1];
        fusage.value = fileinfo[2];
        fdesc.value = fileinfo[3];

        if  (idx>-1) {
            if (typeof fileIndex[idx][5] != 'undefined') {
                fsize.value = fileIndex[idx][5].byteLength;   
            }
        }

    }



    // Update file info controls from index
    function updateCtrlsFromRecord(fnumstr) {
        let ftype = document.getElementById('fileType');
        let fusage = document.getElementById('fileUsage');
        let fdesc = document.getElementById('fileDesc');
        let fsize = document.getElementById('fileSize');

        ftype.value = '';
        fusage.value = '';

        if (fileIndex) {
            dirLength = fileIndex.length;
            let idx = findFileRecord(fnumstr);
            if (idx>-1) {
                if (fileIndex[idx][1]) ftype.value = fileIndex[idx][1];
                if (fileIndex[idx][2]) fusage.value = fileIndex[idx][2];
                if (fileIndex[idx][3]) fdesc.value = fileIndex[idx][3];
                if (typeof fileIndex[idx][5] != 'undefined') fsize.value = fileIndex[idx][5].byteLength;
            }
        }
    }


    // Get file information from 405x Flash Drive filename
    // Returns file number for valid flash file, otherwise NULL
    function isFlashFile(filename){
        let fnumval = 0;
        fnumval = parseInt(filename.substring(0,6));
        if (isNaN(fnumval)) return null;
        let ftype = filename.charAt(7);
        if (!isFileTypeValid(ftype)) return null;
        let fusage = '';
        if (ftype != 'L') {  // Skip over type usage for type LAST        
            fusage = filename.charAt(15);
            if (!isFileUsageValid(fusage)) return null;
        }
        let fdesc = getFileDescription(filename);
        let fileinfo = [fnumval, ftype, fusage, fdesc, filename];
        return fileinfo;
    }


    // Update the file record from given parameters
    // Record is updated if present or created if not
    function updateFileRecord(fileinfo){
        let idx = findFileRecord(fileinfo[0]);
        if (idx>-1) {
            // Record already exists so update
            fileIndex[idx][1] = fileinfo[1];    // File type
            fileIndex[idx][2] = fileinfo[2];    // File usage
            fileIndex[idx][3] = fileinfo[3];    // File description
            fileIndex[idx][4] = fileinfo[4];    // File full name
        }else{
            // Create a new record
            fileIndex.push(fileinfo);
        }
    }


    // Updates file record from the status of the controls
    function updateRecordFromControls(idx) {
        let ftype = document.getElementById('fileType').value;
        let fusage = document.getElementById('fileUsage').value;
        let fdesc = document.getElementById('fileDesc').value;
//        let idx = findFileRecord(currentFile);

        if (idx>-1) {
            // Update the existing record
            fileIndex[idx][1] = ftype;
            fileIndex[idx][2] = fusage;
            fileIndex[idx][3] = fdesc;
        }
/*
         else{
            // Create a new record
            let fileinfo = [fnum, ftype, fusage, fdesc, "", ""];
            fileIndex.push(fileinfo);
        }
*/
    }


/*
    // Get the file record for the given index number
    function getFileRecord(idx) {
        return fileIndex[idx];
    }
*/

    // Checks whether file TYPE is valid
    function isFileTypeValid(ftype){
        for (let i in fileTypes){
            if (fileTypes[i].idx == ftype) return true;
        }
        return false;
    }


    // Checks whether file USAGE is valid
    function isFileUsageValid(fusage){
        for (let i in fileUsages){
            if (fileUsages[i].idx == fusage) return true;
        }
        return false;
    }


    // Get or construct file name from the file information in the index
    function getFilename(fnumstr) {
        let idx = findFileRecord(fnumstr);
        let filename = "";
        let desclen = fileLength - 30;

        if (idx > -1) {

            let fnum = String(fileIndex[idx][0]);
            let ftype = "";

            for (let i=0; i<fileTypes.length; i++){
                if (fileTypes[i].idx == fileIndex[idx][1]) ftype = fileTypes[i].type;
            }

            let fusage = "";
            for (let i=0; i<fileUsages.length; i++){
                if (fileUsages[i].idx == fileIndex[idx][2]) fusage = fileUsages[i].usage;
            }

            let fdesc = "";
            if ( (fileIndex[idx][3] == "") && (fileIndex[idx][4] = "") ) {
                fdesc = "";
            }else{
                if (fileIndex[idx][3] == "") {
                    fdesc = getFileDescription(fileIndex[idx][4]);
                   }else{
                       fdesc = fileIndex[idx][3];
                   }
            }

            let fsizestr = 0;

            if (typeof fileIndex[idx][5] != 'undefined') fsizestr = fileIndex[idx][5].byteLength.toString();

            // Construct filename
            filename = fnum.padEnd(7) + ftype.padEnd(8) + fusage.padEnd(5) + fdesc.padEnd(desclen) + ' ' + fsizestr;
        }

        return filename;

    }


    // Extracts the file description from the file name
    function getFileDescription(filename) {
        let ch = '';
        let desc = "";
        let depos = getLastSpacePos(filename);
        let desclength = fileLength - 30;   // 30 = fnum[7] + ftype[8] + fusage[5] + fsize[7] + CR + NULL

        // Extract description
        for (let i=20; i<depos; i++) {
            ch = filename.charAt(i);
            if ( (ch != '[') && (ch != ']') ) {
                desc = desc + ch;
            }
        }

        // Truncate to 13 characters, pad if required
        desc = desc.substr(0,desclength);
        desc = desc.padEnd(desclength);
        return desc;
    }


    // Update the file size parameter
    function updateFileSize(fnumstr, filename){
        let depos = getLastSpacePos(filename);
        let fname = filename.substring(0, depos);
        let fsizestr = 0;
        if (fileIndex[fnumstr][5]) fsizestr = fileIndex[fnumstr][5].byteLength.toString();
        fname = fname + fsizestr;
        return fname;
    }


    // Determine the position of the final space (start of file size)
    function getLastSpacePos(filename) {
        let lspos = filename.length;
        let ch = '';
        while ( (ch != ' ') && (lspos > 0) ) {
            ch = filename.charAt(lspos);
            lspos--;
        } 
        return lspos;
    }

    // Limits the file description field Limit so a specific length
    this.fdLimit = function() {
        let ftype = document.getElementById('fileType').value;
        let fdescobj = document.getElementById('fileDesc');

        if ( (ftype=='') || (ftype=='L') ) {
            fdescobj.value = "";    // Can't name a LAST or NEW file
            return true;
        }

        let desclen = fileLength - 30;
        let fdesc = fdescobj.value;

        if (fdesc.length >= desclen) {
            fdesc = fdesc.substr(0, desclen);
            fdescobj.value = fdesc;
        }
    }


    // get the next available free file number
    function getNextAvailableFnum(){
        let filelistobj = document.getElementById('fileList');
        let keylist = [];
        for (let i=0; i<filelistobj.length; i++){
            keylist.push(filelistobj.options[i].value);
        }
        keylist = keylist.sort(function(a,b){return a - b});
        for (let i=0; i<255; i++){
            if (parseInt(keylist[i]) != (i+1)) return i+1;
        }
        return null;
    }

    // Debug
    this.showArray = function(){
        console.log("File array: ", fileIndex);
    }


}    // End function Storage


function showStorageMsg(msg, btncolor, btnstatus){
    let messageObj = document.getElementById('storageNotify');
    let messageBtnObj = document.getElementById('notifyBtn');
    if (btnstatus) messageBtnObj.disabled = false;
    if (btncolor) messageObj.style.background = btncolor;
    document.getElementById('storageMsg').innerHTML = msg;
    messageObj.style.display="block";
}



function clearStorageMsg(){
    let messageObj = document.getElementById('storageNotify');
    let messageBtnObj = document.getElementById('notifyBtn');
    messageObj.style.display="none";
    messageBtnObj.disabled = true;
}


//Debug
function getFnameTest(fnumstr){
    let fname = getFilename(fnumstr);
//    console.log("Filename: " + fname);
}



